import json
import boto3
import base64
import os
import uuid
from datetime import datetime
from typing import Dict, Any

# Initialize S3 client
s3_client = boto3.client('s3')

# Environment variables
S3_BUCKET = os.environ.get('S3_BUCKET_NAME', 'vani chitra')
S3_PREFIX = os.environ.get('S3_PREFIX', 'uploads/')

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    AWS Lambda handler for uploading images to S3.
    Creates directory structure if needed and uploads the image.
    
    Expected event structure:
    {
        "body": base64-encoded multipart/form-data with image file
        "headers": {
            "content-type": "multipart/form-data; boundary=..."
        }
    }
    """
    try:
        print(f"Upload request received. Bucket: {S3_BUCKET}, Prefix: {S3_PREFIX}")
        
        # Parse the JSON body
        body = event
        if 'body' in event:
            if isinstance(event['body'], str):
                body = json.loads(event['body'])
            else:
                body = event['body']
                
        base64_string = body.get('image_base64', '')
        
        if not base64_string:
            return create_error_response(400, "No image_base64 found in JSON body")
            
        # Remove data URI prefix if present (e.g., "data:image/jpeg;base64,")
        if ',' in base64_string:
            base64_string = base64_string.split(',')[1]
            
        image_data = base64.b64decode(base64_string)
        
        # Generate unique filename with timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        unique_id = str(uuid.uuid4())[:8]
        filename = f"document_{timestamp}_{unique_id}.jpg"
        
        # Create S3 key with directory structure
        s3_key = f"{S3_PREFIX}{filename}"
        
        print(f"Uploading image to S3: {S3_BUCKET}/{s3_key}")
        print(f"Image size: {len(image_data)} bytes")
        
        # Upload to S3 (S3 automatically creates the "directory" structure)
        s3_client.put_object(
            Bucket=S3_BUCKET,
            Key=s3_key,
            Body=image_data,
            ContentType='image/jpeg',
            Metadata={
                'upload-timestamp': timestamp,
                'original-filename': 'document.jpg'
            }
        )
        
        # Generate S3 URI
        s3_uri = f"s3://{S3_BUCKET}/{s3_key}"
        
        print(f"Upload successful! S3 URI: {s3_uri}")
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            'body': json.dumps({
                'success': True,
                's3_uri': s3_uri,
                's3_bucket': S3_BUCKET,
                's3_key': s3_key,
                'filename': filename
            })
        }
        
    except Exception as e:
        print(f"Error uploading image: {str(e)}")
        import traceback
        traceback.print_exc()
        return create_error_response(500, f"Upload failed: {str(e)}")


# parse_multipart_form_data removed as it is no longer used


def create_error_response(status_code: int, message: str) -> Dict[str, Any]:
    """
    Create a standardized error response.
    
    Args:
        status_code: HTTP status code
        message: Error message
        
    Returns:
        Lambda response dictionary
    """
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'POST, OPTIONS'
        },
        'body': json.dumps({
            'success': False,
            'error': message
        })
    }
