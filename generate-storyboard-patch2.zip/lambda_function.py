import json
import boto3
import base64
import os
from typing import Dict, Any

# Initialize AWS clients
s3_client = boto3.client('s3', region_name='us-east-1')
bedrock_runtime = boto3.client('bedrock-runtime', region_name='us-east-1')

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    AWS Lambda handler for multimodal RAG comic storyboard generation.
    
    Expected event structure:
    {
        "image_s3_uri": "s3://bucket-name/path/to/image.jpg",
        "transcribed_text": "User's voice input transcribed by Amazon Transcribe",
        "target_language": "hi"  # Optional, defaults to English
    }
    """
    try:
        # Parse API Gateway event body
        body = event
        if 'body' in event:
            if isinstance(event['body'], str):
                body = json.loads(event['body'])
            else:
                body = event['body']
                
        # Extract input parameters
        image_s3_uri = body.get('image_s3_uri')
        transcribed_text = body.get('transcribed_text')
        target_language = body.get('target_language', 'en')
        
        # Validate inputs
        if not image_s3_uri or not transcribed_text:
            return create_error_response(
                400,
                "Missing required parameters: image_s3_uri and transcribed_text"
            )
        
        # Step 1: Get image from S3
        image_data = get_image_from_s3(image_s3_uri)
        
        # Step 2: Prepare multimodal prompt for Claude 3.5 Sonnet
        prompt = create_multimodal_prompt(transcribed_text, target_language)
        
        # Step 3: Invoke Amazon Bedrock with Claude 3.5 Sonnet
        storyboard_result = invoke_bedrock_claude(image_data, prompt)
        
        # Step 4: Return result as JSON
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'success': True,
                'storyboard': storyboard_result,
                'metadata': {
                    'image_uri': image_s3_uri,
                    'target_language': target_language,
                    'model': 'anthropic.claude-3-5-sonnet-20240620-v1:0'
                }
            })
        }
        
    except Exception as e:
        print(f"Error processing request: {str(e)}")
        return create_error_response(500, f"Internal server error: {str(e)}")


def get_image_from_s3(s3_uri: str) -> bytes:
    """
    Retrieve image from S3 and return as bytes.
    
    Args:
        s3_uri: S3 URI in format s3://bucket-name/path/to/image.jpg
        
    Returns:
        Image data as bytes
    """
    # Parse S3 URI
    if not s3_uri.startswith('s3://'):
        raise ValueError(f"Invalid S3 URI format: {s3_uri}")
    
    parts = s3_uri[5:].split('/', 1)
    if len(parts) != 2:
        raise ValueError(f"Invalid S3 URI format: {s3_uri}")
    
    bucket_name = parts[0]
    object_key = parts[1]
    
    # Get object from S3
    response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
    image_data = response['Body'].read()
    
    print(f"Retrieved image from S3: {bucket_name}/{object_key}, size: {len(image_data)} bytes")
    return image_data


def create_multimodal_prompt(transcribed_text: str, target_language: str) -> str:
    """
    Create a multimodal prompt for Claude 3.5 Sonnet.
    
    Args:
        transcribed_text: User's voice input transcribed by Amazon Transcribe
        target_language: Target language code for output
        
    Returns:
        Formatted prompt string
    """
    language_map = {
        'hi': 'Hindi',
        'mr': 'Marathi',
        'ta': 'Tamil',
        'te': 'Telugu',
        'bn': 'Bengali',
        'gu': 'Gujarati',
        'kn': 'Kannada',
        'ml': 'Malayalam',
        'pa': 'Punjabi',
        'en': 'English'
    }
    
    language_name = language_map.get(target_language, 'English')
    
    prompt = f"""Analyze this document image and the user's query to generate a 3-step action guide in a comic storyboard format.

User's Query (from voice input): "{transcribed_text}"

Instructions:
1. Carefully examine the document image to understand its content, purpose, and key information
2. Consider the user's voice query to understand their specific needs or questions
3. Create a 3-panel comic storyboard that explains the document in simple, visual terms

Generate a JSON response with the following structure:
{{
    "panel_1": {{
        "title": "Introduction",
        "description": "Brief description of what this panel shows (the document type and main subject)",
        "visual_elements": "Describe the visual elements to be illustrated",
        "caption": "Simple caption in {language_name} explaining the document"
    }},
    "panel_2": {{
        "title": "Key Information",
        "description": "Brief description of what this panel shows (key information or problem)",
        "visual_elements": "Describe the visual elements to be illustrated",
        "caption": "Simple caption in {language_name} explaining the main points"
    }},
    "panel_3": {{
        "title": "Action Required",
        "description": "Brief description of what this panel shows (action required or resolution)",
        "visual_elements": "Describe the visual elements to be illustrated",
        "caption": "Simple caption in {language_name} explaining what to do next"
    }},
    "summary": "A brief overall summary in {language_name} at 5th-grade reading level"
}}

Important guidelines:
- Keep all captions simple and at a 5th-grade reading level
- Use visual metaphors that are culturally appropriate for rural Indian audiences
- Focus on actionable information (dates, amounts, deadlines, required actions)
- Make the storyboard easy to understand for users with limited literacy
- All captions and summary must be in {language_name}
- Ensure the visual descriptions are clear enough for an illustrator to create the comic panels

Return ONLY the JSON response, no additional text."""
    
    return prompt


def invoke_bedrock_claude(image_data: bytes, prompt: str) -> Dict[str, Any]:
    """
    Invoke Amazon Bedrock with Claude 3.5 Sonnet using multimodal input.
    
    Args:
        image_data: Image data as bytes
        prompt: Text prompt for Claude
        
    Returns:
        Parsed storyboard result as dictionary
    """
    # Encode image to base64
    image_base64 = base64.b64encode(image_data).decode('utf-8')
    
    # Prepare the request body for Claude 3.5 Sonnet
    request_body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 4096,
        "temperature": 0.7,
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": "image/jpeg",
                            "data": image_base64
                        }
                    },
                    {
                        "type": "text",
                        "text": prompt
                    }
                ]
            }
        ]
    }
    
    # Invoke Bedrock
    model_id = "anthropic.claude-3-5-sonnet-20240620-v1:0"
    
    print(f"Invoking Bedrock model: {model_id}")
    response = bedrock_runtime.invoke_model(
        modelId=model_id,
        contentType="application/json",
        accept="application/json",
        body=json.dumps(request_body)
    )
    
    # Parse response
    response_body = json.loads(response['body'].read())
    
    # Extract the generated text from Claude's response
    generated_text = response_body['content'][0]['text']
    
    # Parse the JSON response from Claude
    try:
        storyboard_data = json.loads(generated_text)
        print("Successfully parsed storyboard JSON from Claude response")
        return storyboard_data
    except json.JSONDecodeError:
        # If Claude didn't return pure JSON, try to extract it
        print("Warning: Claude response was not pure JSON, attempting to extract")
        # Try to find JSON in the response
        start_idx = generated_text.find('{')
        end_idx = generated_text.rfind('}') + 1
        if start_idx != -1 and end_idx > start_idx:
            json_str = generated_text[start_idx:end_idx]
            storyboard_data = json.loads(json_str)
            return storyboard_data
        else:
            raise ValueError("Could not extract valid JSON from Claude response")


def create_error_response(status_code: int, message: str) -> Dict[str, Any]:
    """
    Create a standardized error response.
    
    Args:
        status_code: HTTP status code
        message: Error message
        
    Returns:
        Lambda response dictionary
    """
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({
            'success': False,
            'error': message
        })
    }
