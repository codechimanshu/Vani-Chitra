import json
import boto3
import os
from typing import Dict, Any

# Initialize AWS clients
polly_client = boto3.client('polly', region_name='us-east-1')

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    AWS Lambda handler for audio generation using Amazon Polly.
    
    Expected event structure:
    {
        "body": JSON string with:
        {
            "text": "Text to convert to speech",
            "language": "hi"
        }
    }
    """
    try:
        print("Audio generation request received")
        
        # Parse request body
        body = json.loads(event.get('body', '{}'))
        text = body.get('text', '')
        language = body.get('language', 'hi')
        
        if not text:
            return create_error_response(400, "No text provided")
        
        print(f"Generating audio for text (length: {len(text)}), language: {language}")
        
        # Map language codes to Polly voice IDs
        voice_map = {
            'hi': 'Aditi',      # Hindi (Indian)
            'en': 'Kajal',      # English (Indian)
            'mr': 'Aditi',      # Marathi (use Hindi voice)
            'ta': 'Aditi',      # Tamil (use Hindi voice)
            'te': 'Aditi',      # Telugu (use Hindi voice)
            'bn': 'Aditi',      # Bengali (use Hindi voice)
            'gu': 'Aditi',      # Gujarati (use Hindi voice)
            'kn': 'Aditi',      # Kannada (use Hindi voice)
            'ml': 'Aditi',      # Malayalam (use Hindi voice)
            'pa': 'Aditi'       # Punjabi (use Hindi voice)
        }
        
        voice_id = voice_map.get(language, 'Aditi')
        
        # Generate speech using Amazon Polly
        response = polly_client.synthesize_speech(
            Text=text,
            OutputFormat='mp3',
            VoiceId=voice_id,
            Engine='neural'  # Use neural engine for better quality
        )
        
        # Get audio stream
        audio_stream = response['AudioStream'].read()
        
        print(f"Audio generated successfully, size: {len(audio_stream)} bytes")
        
        # Return audio as binary response
        import base64
        audio_base64 = base64.b64encode(audio_stream).decode('utf-8')
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'audio/mpeg',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            'body': audio_base64,
            'isBase64Encoded': True
        }
        
    except Exception as e:
        print(f"Error generating audio: {str(e)}")
        import traceback
        traceback.print_exc()
        return create_error_response(500, f"Audio generation failed: {str(e)}")


def create_error_response(status_code: int, message: str) -> Dict[str, Any]:
    """Create a standardized error response."""
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'POST, OPTIONS'
        },
        'body': json.dumps({
            'success': False,
            'error': message
        })
    }
