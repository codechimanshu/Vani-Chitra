# Note: boto3 is provided by the AWS Lambda runtime environment.
# If seeing errors locally, it's because it's not installed in your local python env.
import json
import boto3
import base64
import os
import traceback
from typing import Dict, Any, List, Optional

# Initialize AWS clients
s3_client = boto3.client('s3', region_name='us-east-1')
textract_client = boto3.client('textract', region_name='us-east-1')

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    AWS Lambda handler that uses AWS Textract to read the document 
    and generates a functional dynamic storyboard based on the text.
    """
    try:
        # Parse API Gateway event body
        body: Dict[str, Any] = {}
        if isinstance(event, dict):
            event_body = event.get('body')
            if isinstance(event_body, str):
                try:
                    body = json.loads(event_body)
                except json.JSONDecodeError:
                    body = {}
            elif isinstance(event_body, dict):
                body = event_body
            else:
                body = event
        else:
            body = {}
                
        # Extract input parameters
        image_s3_uri: str = str(body.get('image_s3_uri', ""))
        transcribed_text: str = str(body.get('transcribed_text', ""))
        
        # Validate inputs
        if not image_s3_uri or image_s3_uri == "":
            return create_error_response(400, "Missing required parameter: image_s3_uri")
            
        print(f"Scanning document via Textract: {image_s3_uri}")
        
        # Step 1: Get image from S3 to memory
        image_data = get_image_from_s3(image_s3_uri)

        # Step 2: Call AWS Textract OCR directly with bytes
        textract_response = textract_client.detect_document_text(
            Document={'Bytes': image_data}
        )
        
        extracted_words: List[str] = []
        blocks: List[Dict[str, Any]] = textract_response.get('Blocks', [])
        for block in blocks:
            if block.get('BlockType') == 'WORD':
                word_text: str = str(block.get('Text', ""))
                extracted_words.append(word_text.lower())
                
        document_text: str = " ".join(extracted_words)
        print(f"Extracted Text: {document_text}")

        # Build dynamic storyboard based on OCR results and Voice Query
        story_result = generate_dynamic_storyboard(document_text, transcribed_text.lower())
        
        # Return result as JSON
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'success': True,
                'storyboard': story_result,
                'metadata': {
                    'image_uri': image_s3_uri,
                    'textract_characters': len(document_text),
                    'method': 'textract_rules_engine'
                }
            })
        }
        
    except Exception as e:
        print(f"Error processing request: {str(e)}")
        import traceback
        traceback.print_exc()
        return create_error_response(500, f"Internal server error: {str(e)}")


def generate_dynamic_storyboard(doc_text: str, voice_text: str) -> Dict[str, Any]:
    """
    Analyzes the extracted OCR text and generates a matching Hindi Storyboard.
    Tries Bedrock first, falls back to Rules Engine.
    """
    combined_text = str(doc_text + " " + voice_text).lower()
    
    # 1. Try AI (AWS Bedrock)
    try:
        bedrock_client = boto3.client('bedrock-runtime', region_name='us-east-1')
        
        prompt = f"""
        You are Vani-Chitra, an AI that simplifies complex documents for rural Indian users.
        Read the following document text and optionally a voice query from the user.
        Translate the meaning and simplify it to a 5th-grade reading level in Hindi.
        
        Return EXACTLY AND ONLY a valid JSON object with this exact structure, nothing else:
        {{
            "panel_1": {{
                "title": "Title in English",
                "description": "English description of scene",
                "visual_elements": "English visual prompt for image generation",
                "caption": "Hindi translation / simplified explanation for panel 1"
            }},
            "panel_2": {{
                "title": "Title in English",
                "description": "English description of scene",
                "visual_elements": "English visual prompt for image generation",
                "caption": "Hindi translation / simplified explanation for panel 2"
            }},
            "panel_3": {{
                "title": "Title in English",
                "description": "English description of scene",
                "visual_elements": "English visual prompt for image generation",
                "caption": "Hindi translation / simplified explanation for panel 3"
            }},
            "summary": "Overall summary of the document in plain Hindi."
        }}
        
        Document Text: {doc_text}
        User Voice Query: {voice_text}
        """

        response = bedrock_client.invoke_model(
            modelId='anthropic.claude-3-5-sonnet-20240620-v1:0',
            contentType='application/json',
            accept='application/json',
            body=json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 1000,
                "messages": [
                    {"role": "user", "content": prompt}
                ]
            })
        )
        
        response_data = json.loads(response['body'].read())
        content_text = response_data['content'][0]['text']
        
        # Clean up markdown output
        if '```json' in content_text:
            content_text = content_text.split('```json')[1].split('```')[0].strip()
        elif '```' in content_text:
            content_text = content_text.split('```')[1].strip()
            
        return json.loads(content_text)
        
    except Exception as e:
        print(f"Bedrock failed, falling back to Rules Engine: {str(e)}")
        
        # 2. Rules Engine Fallback
        fallback_res: Dict[str, Any] = {
            "panel_1": {
                "title": "Introduction",
                "caption": "यह दस्तावेज़ एक सामान्य सूचना है।"
            },
            "panel_2": {
                "title": "Details",
                "caption": "कृपया दस्तावेज़ में दी गई जानकारी को ध्यान से पढ़ें।"
            },
            "panel_3": {
                "title": "Action",
                "caption": "अधिक जानकारी के लिए नज़दीकी जन सेवा केंद्र (CSC) से संपर्क करें।"
            },
            "summary": "यह दस्तावेज़ सामान्य जानकारी के लिए है। अगर आपको समझने में दिक्कत हो, तो कृपया सहायता लें। [V2]"
        }

        # Banking / Scheme / KYC
        if any(word in combined_text for word in ['pm', 'kisan', 'bank', 'account', 'aadhaar', 'kyc', 'paisa', 'rupee', 'labh']):
            fallback_res["panel_1"]["caption"] = "यह दस्तावेज़ सरकारी योजना या बैंक खाते के बारे में है।"
            fallback_res["panel_2"]["caption"] = "दस्तावेज़ के अनुसार आपको अपना बैंक खाता अपडेट या आधार से लिंक करना चाहिए।"
            fallback_res["panel_3"]["caption"] = "कृपया तुरंत अपने बैंक या जन सेवा केंद्र (CSC) जाकर ई-केवाईसी पूरा करें।"
            fallback_res["summary"] = "इस पत्र में आपके बैंक खाते या सरकारी लाभ से जुड़ी जानकारी है। पैसे न रुकें, इसलिए अपना आधार लिंक करवा लें।"
            
        # Health / Medical
        elif any(word in combined_text for word in ['health', 'hospital', 'doctor', 'medicine', 'ilaj', 'dawa', 'ayushman', 'card']):
            fallback_res["panel_1"]["caption"] = "यह दस्तावेज़ आपके स्वास्थ्य और इलाज के बारे में है।"
            fallback_res["panel_2"]["caption"] = "इसमें अस्पताल की सुविधाओं या मुफ्त मेडिकल आयुष्मान कार्ड का ज़िक्र है।"
            fallback_res["panel_3"]["caption"] = "कृपया इस दस्तावेज़ को अस्पताल ले जाएं और डॉक्टर से सलाह लें।"
            fallback_res["summary"] = "यह एक मेडिकल रिपोर्ट है। इसे संभाल कर रखें और इलाज के समय डॉक्टर को दिखाएं।"
            
        # Agriculture / Farming
        elif any(word in combined_text for word in ['crop', 'kheti', 'fasal', 'beej', 'kisan', 'bima', 'season', 'weather']):
            fallback_res["panel_1"]["caption"] = "यह दस्तावेज़ खेती और फसल की जानकारी के बारे में है।"
            fallback_res["panel_2"]["caption"] = "इसमें फसल बीमा (Bima) या खाद और बीज के सही उपयोग की जानकारी है।"
            fallback_res["panel_3"]["caption"] = "फसल को बचाने के लिए मौसम के अनुसार तैयारी करें और कृषि अधिकारी से मिलें।"
            fallback_res["summary"] = "इस पर्चे में आपकी फसल को बेहतर बनाने और बीमा योजना के लाभों की जानकारी दी गई है।"

        return fallback_res


def create_error_response(status_code: int, message: str) -> Dict[str, Any]:
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({
            'success': False,
            'error': message
        })
    }

def get_image_from_s3(s3_uri: str) -> bytes:
    """Retrieve image from S3 and return as bytes."""
    if not s3_uri.startswith('s3://'):
        raise ValueError(f"Invalid S3 URI format: {s3_uri}")
    
    s3_path = s3_uri.replace('s3://', '', 1)
    parts = s3_path.split('/', 1)
    if len(parts) != 2:
        raise ValueError(f"Invalid S3 URI format: {s3_uri}")
    
    bucket_name = str(parts[0])
    object_key = str(parts[1])
    
    response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
    return response['Body'].read()
