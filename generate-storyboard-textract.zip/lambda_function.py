import json
import boto3
import base64
import os
from typing import Dict, Any

# Initialize AWS clients
textract_client = boto3.client('textract', region_name='us-east-1')

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    AWS Lambda handler that uses AWS Textract to read the document 
    and generates a functional dynamic storyboard based on the text.
    """
    try:
        # Parse API Gateway event body
        body = event
        if 'body' in event:
            if isinstance(event['body'], str):
                body = json.loads(event['body'])
            else:
                body = event['body']
                
        # Extract input parameters
        image_s3_uri = body.get('image_s3_uri')
        transcribed_text = body.get('transcribed_text', "")
        
        # Validate inputs
        if not image_s3_uri:
            return create_error_response(400, "Missing required parameter: image_s3_uri")
            
        print(f"Scanning document via Textract: {image_s3_uri}")
        
        # Parse S3 URI for Textract
        parts = image_s3_uri[5:].split('/', 1)
        bucket = parts[0]
        key = parts[1]

        # Call AWS Textract OCR (This does NOT require Bedrock Marketplace Subscription)
        textract_response = textract_client.detect_document_text(
            Document={'S3Object': {'Bucket': bucket, 'Name': key}}
        )
        
        extracted_words = []
        for block in textract_response.get('Blocks', []):
            if block['BlockType'] == 'WORD':
                extracted_words.append(block['Text'].lower())
                
        document_text = " ".join(extracted_words)
        print(f"Extracted Text: {document_text}")

        # Build dynamic storyboard based on OCR results and Voice Query
        story_result = generate_dynamic_storyboard(document_text, transcribed_text.lower())
        
        # Return result as JSON
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'success': True,
                'storyboard': story_result,
                'metadata': {
                    'image_uri': image_s3_uri,
                    'textract_characters': len(document_text),
                    'method': 'textract_rules_engine'
                }
            })
        }
        
    except Exception as e:
        print(f"Error processing request: {str(e)}")
        import traceback
        traceback.print_exc()
        return create_error_response(500, f"Internal server error: {str(e)}")


def generate_dynamic_storyboard(doc_text: str, voice_text: str) -> Dict[str, Any]:
    """
    Analyzes the extracted OCR text and generates a matching Hindi Storyboard.
    """
    # Default Agricultural Fallback
    response = {
        "panel_1": {
            "title": "Introduction",
            "description": "A farmer examining a general notice.",
            "visual_elements": "A farmer looking at a generic agricultural notice board in the village.",
            "caption": "यह दस्तावेज़ एक सामान्य कृषि सूचना है।"
        },
        "panel_2": {
            "title": "Key Information",
            "description": "Details about the notice.",
            "visual_elements": "Close up of the notice with important dates highlighted.",
            "caption": "कृपया दस्तावेज़ में दी गई जानकारी को ध्यान से पढ़ें।"
        },
        "panel_3": {
            "title": "Action Required",
            "description": "Seeking help from CSC.",
            "visual_elements": "The farmer asking the local CSC agent for clarification.",
            "caption": "अधिक जानकारी के लिए कृपया अपने नज़दीकी पंचायत घर या जन सेवा केंद्र से संपर्क करें।"
        },
        "summary": "यह दस्तावेज़ सामान्य जानकारी के लिए है। अगर आपको पढ़ने में कठिनाई हो रही है, तो कृपया गाँव के सरपंच या जन सेवा केंद्र से सहायता लें।"
    }

    combined_text = doc_text + " " + voice_text

    # Rules Engine: Payment / Scheme / KYC
    if any(word in combined_text for word in ['pm', 'kisan', 'samman', 'nidhi', 'bank', 'account', 'aadhaar', 'kyc', 'link', 'db']):
        response["panel_1"]["caption"] = "यह दस्तावेज़ पीएम किसान योजना और बैंक खाते के बारे में है।"
        response["panel_2"]["caption"] = "दस्तावेज़ के अनुसार आपको अपने बैंक खाते को आधार कार्ड से लिंक करना (e-KYC) ज़रूरी है।"
        response["panel_3"]["caption"] = "कृपया तुरंत अपने बैंक या नज़दीकी मोबाइल सेंटर (CSC) पर जाकर ई-केवाईसी पूरा करें।"
        response["summary"] = "इस सरकारी पत्र में कहा गया है कि योजना के पैसे प्राप्त करने के लिए आपका आधार और बैंक खाता लिंक होना चाहिए। कृपया जन सेवा केंद्र जाएं और यह काम जल्द करवा लें ताकि पैसे न रुकें।"
        
    # Rules Engine: Health / Hospital / Medicines
    elif any(word in combined_text for word in ['health', 'hospital', 'doctor', 'medicine', 'clinic', 'swasthya', 'ayushman', 'card', 'fever', 'disease']):
        response["panel_1"]["caption"] = "यह दस्तावेज़ स्वास्थ्य और अस्पताल से जुड़ी जानकारी के बारे में है।"
        response["panel_2"]["caption"] = "इसमें आपके इलाज या आयुष्मान कार्ड से मिलने वाली मुफ्त मेडिकल सुविधाओं का ज़िक्र है।"
        response["panel_3"]["caption"] = "कृपया दस्तावेज़ को लेकर सरकारी अस्पताल जाएं और डॉक्टर को दिखाएं।"
        response["summary"] = "यह एक मेडिकल दस्तावेज़ है। यह आपके या आपके परिवार के इलाज और दवाओं से संबंधित है। कृपया इसे संभाल कर रखें और अगली बार जब आप अस्पताल जाएं तो इसे साथ ले जाएं।"
        
    # Rules Engine: Crop / Weather / Farming / Seed / Insurance
    elif any(word in combined_text for word in ['crop', 'weather', 'insurance', 'bima', 'f फसल', 'seed', 'fertilizer', 'kheti', 'barish', 'water', 'rain']):
        response["panel_1"]["caption"] = "यह दस्तावेज़ खेती, फसल बीमा या मौसम की चेतावनी के बारे में है।"
        response["panel_2"]["caption"] = "इसमें आपकी फसल के बचाव या उचित खाद (Fertilizer) और बीज की जानकारी दी गई है।"
        response["panel_3"]["caption"] = "कृपया मौसम के अनुसार खेती की तैयारी करें और ज़रूरत पड़ने पर कृषि अधिकारी से मिलें।"
        response["summary"] = "इस पर्चे में आपकी फसल और खेती से जुड़े निर्देश दिए गए हैं। इसमें फसल बीमा योजना (Crop Insurance) और सही समय पर बीज बोने की जानकारी हो सकती है। इसे ध्यान में रखकर ही अगली फसल की तैयारी करें।"

    # Rules Engine: Education / School 
    elif any(word in combined_text for word in ['school', 'education', 'exam', 'student', 'vidyalaya', 'shiksha', 'results', 'fees']):
        response["panel_1"]["caption"] = "यह दस्तावेज़ स्कूल या बच्चों की पढ़ाई के संदर्भ में है।"
        response["panel_2"]["caption"] = "इसमें स्कूल की फीस, परीक्षाओं की तारीख या नतीजे (Results) से जुड़ी जानकारी है।"
        response["panel_3"]["caption"] = "कृपया दस्तावेज़ पर ध्यान दें और स्कूल के मास्टर जी से जाकर बात करें।"
        response["summary"] = "यह आपके बच्चे के स्कूल से आया एक महत्वपूर्ण नोटिस है। यह फीस भरने या परीक्षाओं के बारे में हो सकता है। कृपया समय निकालकर स्कूल जाएं और पूरी जानकारी प्राप्त करें।"

    return response

def create_error_response(status_code: int, message: str) -> Dict[str, Any]:
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({
            'success': False,
            'error': message
        })
    }
