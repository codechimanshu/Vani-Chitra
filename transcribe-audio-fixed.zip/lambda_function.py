import json
import boto3
import base64
import os
import uuid
from datetime import datetime
from typing import Dict, Any

# Initialize AWS clients
s3_client = boto3.client('s3', region_name='us-east-1')
transcribe_client = boto3.client('transcribe', region_name='us-east-1')

# Environment variables
S3_BUCKET = os.environ.get('S3_BUCKET_NAME', 'vani-chitra')
S3_PREFIX = os.environ.get('S3_PREFIX', 'audio/')

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    AWS Lambda handler for audio transcription using Amazon Transcribe.
    
    Expected event structure:
    {
        "body": base64-encoded multipart/form-data with audio file
        "headers": {
            "content-type": "multipart/form-data; boundary=..."
        }
    }
    """
    try:
        print("Transcription request received")
        
        # Parse the multipart form data
        audio_data, language = parse_multipart_form_data(event)
        
        if not audio_data:
            return create_error_response(400, "No audio data found in request")
        
        # Generate unique filename
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        unique_id = str(uuid.uuid4())[:8]
        filename = f"audio_{timestamp}_{unique_id}.webm"
        
        # Upload audio to S3
        s3_key = f"{S3_PREFIX}{filename}"
        print(f"Uploading audio to S3: {S3_BUCKET}/{s3_key}")
        
        s3_client.put_object(
            Bucket=S3_BUCKET,
            Key=s3_key,
            Body=audio_data,
            ContentType='audio/webm'
        )
        
        audio_uri = f"s3://{S3_BUCKET}/{s3_key}"
        print(f"Audio uploaded: {audio_uri}")
        
        # Map language codes to Transcribe language codes
        language_map = {
            'hi': 'hi-IN',
            'mr': 'mr-IN',
            'ta': 'ta-IN',
            'te': 'te-IN',
            'bn': 'bn-IN',
            'gu': 'gu-IN',
            'kn': 'kn-IN',
            'ml': 'ml-IN',
            'pa': 'pa-IN',
            'en': 'en-IN'
        }
        
        transcribe_language = language_map.get(language, 'hi-IN')
        job_name = f"transcribe_{timestamp}_{unique_id}"
        
        print(f"Starting transcription job: {job_name}, language: {transcribe_language}")
        
        # Start transcription job
        transcribe_client.start_transcription_job(
            TranscriptionJobName=job_name,
            Media={'MediaFileUri': audio_uri},
            MediaFormat='webm',
            LanguageCode=transcribe_language
        )
        
        # Wait for transcription to complete
        import time
        max_wait = 90  # Maximum 90 seconds
        wait_time = 0
        
        while wait_time < max_wait:
            status = transcribe_client.get_transcription_job(
                TranscriptionJobName=job_name
            )
            
            job_status = status['TranscriptionJob']['TranscriptionJobStatus']
            
            if job_status == 'COMPLETED':
                transcript_uri = status['TranscriptionJob']['Transcript']['TranscriptFileUri']
                print(f"Transcription completed: {transcript_uri}")
                
                # Get transcript text
                import urllib.request
                with urllib.request.urlopen(transcript_uri) as response:
                    transcript_data = json.loads(response.read())
                    transcribed_text = transcript_data['results']['transcripts'][0]['transcript']
                
                print(f"Transcribed text: {transcribed_text}")
                
                # Clean up: delete transcription job
                transcribe_client.delete_transcription_job(
                    TranscriptionJobName=job_name
                )
                
                return {
                    'statusCode': 200,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': 'Content-Type',
                        'Access-Control-Allow-Methods': 'POST, OPTIONS'
                    },
                    'body': json.dumps({
                        'success': True,
                        'transcribed_text': transcribed_text,
                        'language': language,
                        'audio_uri': audio_uri
                    })
                }
            
            elif job_status == 'FAILED':
                failure_reason = status['TranscriptionJob'].get('FailureReason', 'Unknown')
                print(f"Transcription failed: {failure_reason}")
                return create_error_response(500, f"Transcription failed: {failure_reason}")
            
            # Wait and retry
            time.sleep(2)
            wait_time += 2
        
        return create_error_response(408, "Transcription timeout")
        
    except Exception as e:
        print(f"Error transcribing audio: {str(e)}")
        import traceback
        traceback.print_exc()
        return create_error_response(500, f"Transcription failed: {str(e)}")


def parse_multipart_form_data(event: Dict[str, Any]) -> tuple:
    """
    Parse multipart/form-data from API Gateway event.
    
    Returns:
        Tuple of (audio_data: bytes, language: str)
    """
    try:
        body = event.get('body', '')
        is_base64 = event.get('isBase64Encoded', False)
        
        if is_base64:
            body = base64.b64decode(body)
        else:
            body = body.encode('utf-8') if isinstance(body, str) else body
        
        content_type = event.get('headers', {}).get('content-type', '') or \
                      event.get('headers', {}).get('Content-Type', '')
        
        if 'boundary=' not in content_type:
            raise ValueError("No boundary found in Content-Type header")
        
        boundary = content_type.split('boundary=')[1].strip()
        boundary_bytes = f"--{boundary}".encode('utf-8')
        
        parts = body.split(boundary_bytes)
        
        audio_data = None
        language = 'hi'  # Default language
        
        for part in parts:
            # Check for audio file
            if b'Content-Type: audio/' in part or b'name="audio"' in part:
                header_end = part.find(b'\r\n\r\n')
                if header_end != -1:
                    audio_data = part[header_end + 4:].rstrip(b'\r\n--')
            
            # Check for language field
            if b'name="language"' in part:
                header_end = part.find(b'\r\n\r\n')
                if header_end != -1:
                    language = part[header_end + 4:].rstrip(b'\r\n--').decode('utf-8')
        
        return audio_data, language
        
    except Exception as e:
        print(f"Error parsing multipart form data: {str(e)}")
        raise


def create_error_response(status_code: int, message: str) -> Dict[str, Any]:
    """Create a standardized error response."""
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'POST, OPTIONS'
        },
        'body': json.dumps({
            'success': False,
            'error': message
        })
    }
