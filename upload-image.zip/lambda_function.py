import json
import boto3
import base64
import os
import uuid
from datetime import datetime
from typing import Dict, Any

# Initialize S3 client
s3_client = boto3.client('s3')

# Environment variables
S3_BUCKET = os.environ.get('S3_BUCKET_NAME', 'vani chitra')
S3_PREFIX = os.environ.get('S3_PREFIX', 'uploads/')

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    AWS Lambda handler for uploading images to S3.
    Creates directory structure if needed and uploads the image.
    
    Expected event structure:
    {
        "body": base64-encoded multipart/form-data with image file
        "headers": {
            "content-type": "multipart/form-data; boundary=..."
        }
    }
    """
    try:
        print(f"Upload request received. Bucket: {S3_BUCKET}, Prefix: {S3_PREFIX}")
        
        # Parse the multipart form data
        image_data = parse_multipart_form_data(event)
        
        if not image_data:
            return create_error_response(400, "No image data found in request")
        
        # Generate unique filename with timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        unique_id = str(uuid.uuid4())[:8]
        filename = f"document_{timestamp}_{unique_id}.jpg"
        
        # Create S3 key with directory structure
        s3_key = f"{S3_PREFIX}{filename}"
        
        print(f"Uploading image to S3: {S3_BUCKET}/{s3_key}")
        print(f"Image size: {len(image_data)} bytes")
        
        # Upload to S3 (S3 automatically creates the "directory" structure)
        s3_client.put_object(
            Bucket=S3_BUCKET,
            Key=s3_key,
            Body=image_data,
            ContentType='image/jpeg',
            Metadata={
                'upload-timestamp': timestamp,
                'original-filename': 'document.jpg'
            }
        )
        
        # Generate S3 URI
        s3_uri = f"s3://{S3_BUCKET}/{s3_key}"
        
        print(f"Upload successful! S3 URI: {s3_uri}")
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            'body': json.dumps({
                'success': True,
                's3_uri': s3_uri,
                's3_bucket': S3_BUCKET,
                's3_key': s3_key,
                'filename': filename
            })
        }
        
    except Exception as e:
        print(f"Error uploading image: {str(e)}")
        import traceback
        traceback.print_exc()
        return create_error_response(500, f"Upload failed: {str(e)}")


def parse_multipart_form_data(event: Dict[str, Any]) -> bytes:
    """
    Parse multipart/form-data from API Gateway event.
    
    Args:
        event: API Gateway event
        
    Returns:
        Image data as bytes
    """
    try:
        # Get the body (base64 encoded if from API Gateway)
        body = event.get('body', '')
        is_base64 = event.get('isBase64Encoded', False)
        
        if is_base64:
            body = base64.b64decode(body)
        else:
            body = body.encode('utf-8') if isinstance(body, str) else body
        
        # Get content type and boundary
        content_type = event.get('headers', {}).get('content-type', '') or \
                      event.get('headers', {}).get('Content-Type', '')
        
        if 'boundary=' not in content_type:
            raise ValueError("No boundary found in Content-Type header")
        
        boundary = content_type.split('boundary=')[1].strip()
        boundary_bytes = f"--{boundary}".encode('utf-8')
        
        # Split by boundary
        parts = body.split(boundary_bytes)
        
        # Find the part with image data
        for part in parts:
            if b'Content-Type: image/' in part or b'filename=' in part:
                # Find the start of actual image data (after headers)
                header_end = part.find(b'\r\n\r\n')
                if header_end != -1:
                    image_data = part[header_end + 4:]
                    # Remove trailing boundary markers
                    image_data = image_data.rstrip(b'\r\n--')
                    return image_data
        
        raise ValueError("No image data found in multipart form")
        
    except Exception as e:
        print(f"Error parsing multipart form data: {str(e)}")
        raise


def create_error_response(status_code: int, message: str) -> Dict[str, Any]:
    """
    Create a standardized error response.
    
    Args:
        status_code: HTTP status code
        message: Error message
        
    Returns:
        Lambda response dictionary
    """
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'POST, OPTIONS'
        },
        'body': json.dumps({
            'success': False,
            'error': message
        })
    }
